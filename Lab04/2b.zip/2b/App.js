import React, { useState } from 'react';
import { View, Text, TextInput, Button, TouchableOpacity, Image, StyleSheet } from 'react-native';
import Icon from 'react-native-vector-icons/FontAwesome';
import * as ImagePicker from 'expo-image-picker';

const ReviewScreen = () => {
  const [rating, setRating] = useState(5); // Default rating
  const [image, setImage] = useState(null);
  const [review, setReview] = useState('');

  // Hàm trả về thông điệp dựa trên số sao đã chọn
  const getRatingMessage = (rating) => {
    switch (rating) {
      case 1:
        return "Rất không hài lòng";
      case 2:
        return "Không hài lòng";
      case 3:
        return "Bình thường";
      case 4:
        return "Hài lòng";
      case 5:
        return "Cực kỳ hài lòng";
      default:
        return "";
    }
  };

  const pickImage = async () => {
    let result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ImagePicker.MediaTypeOptions.Images,
      allowsEditing: true,
      aspect: [4, 3],
      quality: 1,
    });

    if (!result.cancelled) {
      setImage(result.uri);
    }
  };

  return (
    <View style={styles.container}>
      {/* Thông tin sản phẩm và ảnh */}
      <View style={styles.productInfo}>
        <Image source={{ uri: 'https://link-to-your-usb-image.png' }} style={styles.productImage} />
        <View>
          <Text style={styles.productName}>USB Bluetooth Music Receiver HJX-001</Text>
          <Text style={styles.productDesc}>Biến loa thường thành loa bluetooth</Text>
        </View>
      </View>

      {/* Hiển thị thông điệp dựa trên số sao */}
      <Text style={styles.ratingText}>{getRatingMessage(rating)}</Text>

      {/* Các ngôi sao để chọn đánh giá */}
      <View style={styles.starsContainer}>
        {Array(5).fill().map((_, index) => (
          <Icon
            key={index}
            name="star"
            size={30}
            color={index < rating ? "#FFD700" : "#CCC"}
            onPress={() => setRating(index + 1)} // Cập nhật số sao đã chọn
          />
        ))}
      </View>

      {/* Nút thêm hình ảnh */}
      <TouchableOpacity style={styles.imageButton} onPress={pickImage}>
        <Icon name="camera" size={20} color="#000" />
        <Text style={styles.imageText}>Thêm hình ảnh</Text>
      </TouchableOpacity>

      {image && <Image source={{ uri: image }} style={styles.imagePreview} />}

      {/* Text input cho nhận xét */}
      <TextInput
        style={styles.textArea}
        placeholder="Hãy chỉ sẻ những điều mà bạn thích về sản phẩm"
        multiline={true}
        numberOfLines={4}
        value={review}
        onChangeText={setReview}
      />

      {/* Nút gửi */}
      <TouchableOpacity style={styles.submitButton}>
        <Text style={styles.submitButtonText}>Gửi</Text>
      </TouchableOpacity>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
  },
  productInfo: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 20,
  },
  productImage: {
    width: 50,
    height: 50,
    marginRight: 10,
  },
  productName: {
    fontSize: 18,
    fontWeight: 'bold',
  },
  productDesc: {
    fontSize: 14,
    color: '#666',
  },
  ratingText: {
    fontSize: 16,
    marginBottom: 10,
  },
  starsContainer: {
    flexDirection: 'row',
    marginBottom: 20,
  },
  imageButton: {
    flexDirection: 'row',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: '#000',
    borderRadius: 5,
    padding: 10,
    marginBottom: 20,
  },
  imageText: {
    marginLeft: 10,
    fontSize: 14,
  },
  imagePreview: {
    width: 100,
    height: 100,
    marginBottom: 20,
  },
  textArea: {
    borderWidth: 1,
    borderColor: '#CCC',
    borderRadius: 5,
    padding: 10,
    textAlignVertical: 'top',
    marginBottom: 20,
  },
  submitButton: {
    backgroundColor: '#000',
    padding: 15,
    borderRadius: 5,
    alignItems: 'center',
  },
  submitButtonText: {
    color: '#FFF',
    fontWeight: 'bold',
  },
});

export default ReviewScreen;