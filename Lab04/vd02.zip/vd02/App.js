import React, { useState } from 'react';
import { View, Text, Button } from 'react-native';

export default function App() {
  const initialArray = [1, 2, 3];
  const [currentArray, setCurrentArray] = useState(initialArray);
  const [pressCount, setPressCount] = useState(0);

  const handlePress = () => {
    const newArray = currentArray.map(num => num + 1);
    setCurrentArray(newArray);
    setPressCount(pressCount + 1);
  };

  return (
    <View style={{ padding: 20 }}>
      <Button title="Roll dice!" onPress={handlePress} />
      {currentArray.map((num, index) => (
        <Text style={{ fontSize: 24 }} key={index}>
          {num}
        </Text>
      ))}
    </View>
  );
}