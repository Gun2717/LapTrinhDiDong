import React, { useState } from 'react';
import { View, Text, Button } from 'react-native';

export default function App() {
  const [diceRolls, setDiceRolls] = useState([]);
  const [pressCount, setPressCount] = useState(0);

  const handlePress = () => {
    const newDiceRolls = [];
    for (let i = 1; i <= pressCount + 1; i++) {
      newDiceRolls.push(i);
    }
    setDiceRolls(newDiceRolls);
    setPressCount(pressCount + 1);
  };

  return (
    <View style={{ padding: 20 }}>
      <Button title="Roll dice!" onPress={handlePress} />
      {diceRolls.map((diceRoll, index) => (
        <Text style={{ fontSize: 24 }} key={index}>
          {diceRoll}
        </Text>
      ))}
    </View>
  );
}