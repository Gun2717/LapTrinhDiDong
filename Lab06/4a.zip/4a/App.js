import React from 'react';
import { View, Text, FlatList, Image, TouchableOpacity, StyleSheet } from 'react-native';

// Dữ liệu mẫu cho màn hình 1 (bổ sung sản phẩm sách)
const data1 = [
  { id: '1', name: 'Loa bluetooth không dây ZEALOT TWS', shop: 'Tecsire Global Store', image: 'https://down-vn.img.susercontent.com/file/cn-11134207-7r98o-lxqj6mwcidr711' },
  { id: '2', name: 'Gương tròn tân cổ điển màu trắng dát vàng G-735-TDV', shop: 'Wallux', image: 'https://wallux.vn/data/Product/guong-decor-735-tdv-1-1592455267.jpg' },
  { id: '3', name: 'Bàn trà sofa mặt kính gỗ tần bì BT9CT Tundo 74 x 74 x 46 cm', shop: 'Nội Thất Tundo', image: 'https://down-vn.img.susercontent.com/file/vn-11134207-7r98o-lvu01akw4hqx5a' },
  { id: '4', name: 'Giày Tennis Asics Solution Speed FF 3.0 White and Mako Blue', shop: 'GU SPORT', image: 'https://www.gusport.com.vn/image/catalog/san-pham/GIAY/ASICS-NAM/speed-ff-3-0/asics-solution-speed-ff-3-0-white-and-mako-blue-1041a438-102/giay-tennis-asics-solution-speed-ff-3-0-white-and-mako-blue-1041a438-102-1.jpg' },
  { id: '5', name: 'Giày Tennis Asics Nữ Solution Speed FF 3.0 PARIS Safety Yellow/Black', shop: 'GU SPORT', image: 'https://www.gusport.com.vn/image/catalog/san-pham/GIAY/ASICS-NU/speed-ff-3-0/asics-nu-solution-speed-ff-3-0-cos-safety-yellow-black-1042a275-750/giay-tennis-asics-nu-solution-speed-ff-3-0-cos-safety-yellow-black-1042a275-750-1.jpg' }, // Sản phẩm sách đã thêm
  { id: '6', name: 'Bình hoa trang trí HDC.A74', shop: 'Cửa Hàng Hân', image: 'https://hanhomedecor.com/image/cache/catalog/san-pham/21-08-24/mg-5434logo-800x800.jpg' },
];

const Screen1 = ({ navigation }) => {
  return (
    <View style={styles.screenContainer}>
      {/* Thanh công cụ */}
      <View style={styles.header}>
        <TouchableOpacity>
          <Text style={styles.headerIcon}>{'<'}</Text> {/* Nút Back */}
        </TouchableOpacity>
        <Text style={styles.headerText}>Chat</Text>
        <TouchableOpacity>
          <Text style={styles.headerIcon}>🛒</Text> {/* Nút Giỏ hàng */}
        </TouchableOpacity>
      </View>

      {/* Danh sách sản phẩm với hình ảnh */}
      <FlatList
        data={data1}
        keyExtractor={item => item.id}
        renderItem={({ item }) => (
          <View style={styles.productItem}>
            <Image source={{ uri: item.image }} style={styles.productImage} />
            <View style={styles.productInfo}>
              <Text>{item.name}</Text>
              <Text style={styles.shopName}>{item.shop}</Text>
            </View>
            <TouchableOpacity style={styles.chatButton}>
              <Text style={styles.chatButtonText}>Chat</Text>
            </TouchableOpacity>
          </View>
        )}
      />

      {/* Thanh điều hướng dưới */}
      <View style={styles.footer}>
        <TouchableOpacity style={styles.footerButton}>
          <Text style={styles.footerButtonText}>☰</Text> {/* Nút Menu */}
        </TouchableOpacity>
        <TouchableOpacity style={styles.footerButton}>
          <Text style={styles.footerButtonText}>🏠</Text> {/* Nút Home */}
        </TouchableOpacity>
        <TouchableOpacity style={styles.footerButton}>
          <Text style={styles.footerButtonText}>{'<'}</Text> {/* Nút Back */}
        </TouchableOpacity>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  screenContainer: {
    flex: 1,
    padding: 10,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: 15,
    backgroundColor: '#1E90FF',
  },
  headerText: {
    color: 'white',
    fontSize: 18,
  },
  headerIcon: {
    color: 'white',
    fontSize: 24,
  },
  productItem: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    padding: 10,
    borderBottomWidth: 1,
    borderBottomColor: '#ddd',
    alignItems: 'center',
  },
  productImage: {
    width: 80,
    height: 80,
    marginRight: 10,
  },
  productInfo: {
    flex: 1,
  },
  shopName: {
    color: 'gray',
  },
  chatButton: {
    backgroundColor: 'red',
    padding: 10,
    borderRadius: 5,
  },
  chatButtonText: {
    color: 'white',
  },
  footer: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    padding: 10,
    backgroundColor: '#1E90FF',
  },
  footerButton: {
    padding: 10,
  },
  footerButtonText: {
    color: 'white',
    fontSize: 24,
  },
});

export default Screen1;