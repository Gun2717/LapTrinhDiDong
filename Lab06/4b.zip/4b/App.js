import React from 'react';
import { View, Text, FlatList, Image, TextInput, TouchableOpacity, StyleSheet } from 'react-native';

// Dữ liệu mẫu cho màn hình 2
const data2 = [
  { id: '1', name: 'Dây cáp sạc USB Honjianda đa năng 3 trong 1', price: '69.900 đ', rating: 4.5, image: 'https://product.hstatic.net/1000031521/product/lightning_2088e6032dff448998335a6a0c29ddc2_master.jpg' },
  { id: '2', name: 'Cáp sạc nhanh USB 2.0 sang USB Type C dài 1.5M Ugreen 60117', price: '69.900 đ', rating: 4.2, image: 'https://maytinhtrangia.com/wp-content/uploads/cap-sac-nhanh-usb-2.0-sang-type-c-us287-ugreen-60116-6.jpg' },
  { id: '3', name: 'Dây Cáp Sạc USB Type-C Aukey CB-CD2 1.0m', price: '69.900 đ', rating: 3.8, image: 'https://bizweb.dktcdn.net/100/085/471/products/day-cap-sac-5.jpg?v=1646880484747' },
  { id: '4', name: 'Dây cáp sạc USB type-A sang type-C 1M- WUB1501', price: '69.900 đ', rating: 4.0, image: 'https://bizweb.dktcdn.net/thumb/grande/100/351/215/products/wub1501.jpg?v=1691550116410' },
  { id: '5', name: 'Dây cáp bọc dù sạc nhanh Bagi Micro-USB dài 1.5m MH150', price: '69.900 đ', rating: 4.5, image: 'https://bagi.com.vn/wp-content/uploads/2019/09/cap-du-sac-nhanh-mh150-6.jpg' },
];

const Screen2 = ({ navigation }) => {
  return (
    <View style={styles.screenContainer}>
      {/* Thanh công cụ với thanh tìm kiếm */}
      <View style={styles.header}>
        <TouchableOpacity>
          <Text style={styles.headerIcon}>{'<'}</Text> {/* Nút Back */}
        </TouchableOpacity>
        <TextInput style={styles.searchBar} placeholder="Dây cáp USB" />
        <TouchableOpacity>
          <Text style={styles.headerIcon}>🛒</Text> {/* Nút Giỏ hàng */}
        </TouchableOpacity>
      </View>

      {/* Danh sách sản phẩm dạng lưới với hình ảnh */}
      <FlatList
        data={data2}
        keyExtractor={item => item.id}
        numColumns={2}
        renderItem={({ item }) => (
          <View style={styles.gridItem}>
            <Image source={{ uri: item.image }} style={styles.productImage} />
            <Text>{item.name}</Text>
            <Text style={styles.price}>{item.price}</Text>
            <Text>Đánh giá: {item.rating} ★</Text>
          </View>
        )}
      />

      {/* Thanh điều hướng dưới */}
      <View style={styles.footer}>
        <TouchableOpacity style={styles.footerButton}>
          <Text style={styles.footerButtonText}>☰</Text> {/* Nút Menu */}
        </TouchableOpacity>
        <TouchableOpacity style={styles.footerButton}>
          <Text style={styles.footerButtonText}>🏠</Text> {/* Nút Home */}
        </TouchableOpacity>
        <TouchableOpacity style={styles.footerButton}>
          <Text style={styles.footerButtonText}>{'<'}</Text> {/* Nút Back */}
        </TouchableOpacity>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  screenContainer: {
    flex: 1,
    padding: 10,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: 15,
    backgroundColor: '#1E90FF',
  },
  searchBar: {
    flex: 1,
    backgroundColor: 'white',
    borderRadius: 5,
    padding: 10,
    marginLeft: 10,
    marginRight: 10,
  },
  headerIcon: {
    color: 'white',
    fontSize: 24,
  },
  gridItem: {
    flex: 1,
    margin: 5,
    padding: 10,
    backgroundColor: '#f9f9f9',
    borderRadius: 5,
  },
  productImage: {
    width: 150,
    height: 100,
    marginBottom: 10,
  },
  price: {
    color: 'green',
    fontWeight: 'bold',
  },
  footer: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    padding: 10,
    backgroundColor: '#1E90FF',
  },
  footerButton: {
    padding: 10,
  },
  footerButtonText: {
    color: 'white',
    fontSize: 24,
  },
});

export default Screen2;