import React, { useState } from 'react';
import { View, Text, Image, TouchableOpacity, StyleSheet } from 'react-native';

export default function App() {
  const [screen, setScreen] = useState(1);  // Bắt đầu từ màn hình 1
  const [selectedColor, setSelectedColor] = useState(null);  // Màu đã chọn

  // Hàm render màn hình dựa trên trạng thái
  const renderScreen = () => {
    switch (screen) {
      case 1:
        return <Screen1 />;
      case 2:
        return <Screen2 />;
      case 3:
        return <Screen3 />;
      case 4:
        return <Screen4 />;
      default:
        return <Screen1 />;
    }
  };

  // Màn hình 1: Chọn sản phẩm và chọn màu
  const Screen1 = () => (
    <View style={styles.container}>
      <Image source={{ uri: 'https://cdn2.cellphones.com.vn/x/media/catalog/product/i/p/iphone-15-pro-max_4__1.jpg' }} style={styles.image} />
      <Text style={styles.title}>iPhone 12 Pro Max 256GB</Text>
      <Text style={styles.rating}>★★★★☆ (Xem 828 đánh giá)</Text>
      <Text style={styles.price}>27.590.000đ</Text>
      <Text style={styles.oldPrice}>31.990.000đ</Text>
      
      <TouchableOpacity onPress={() => setScreen(2)} style={styles.colorButton}>
        <Text style={styles.colorButtonText}>CHỌN MÀU</Text>
      </TouchableOpacity>
      
      <TouchableOpacity onPress={() => setScreen(4)} style={styles.buyButton}>
        <Text style={styles.buyButtonText}>CHỌN MUA</Text>
      </TouchableOpacity>
    </View>
  );

  // Màn hình 2: Chọn màu và xác nhận
  const Screen2 = () => (
    <View style={styles.container}>
      <View style={styles.header}>
        <Image source={{ uri: 'https://cdn2.cellphones.com.vn/x/media/catalog/product/i/p/iphone-15-pro-max_4__1.jpg' }} style={styles.headerImage} />
        <Text style={styles.headerText}>iPhone 12 Pro Max 256GB</Text>
      </View>

      <Text style={styles.title}>Chọn một màu bên dưới:</Text>
      <View style={styles.colorOptionsVertical}>
        {/* Các ô màu nhỏ hơn và xếp theo hàng dọc */}
        <TouchableOpacity onPress={() => { setSelectedColor('yellow'); setScreen(3); }} style={[styles.colorBox, { backgroundColor: 'yellow' }]} />
        <TouchableOpacity onPress={() => { setSelectedColor('silver'); setScreen(3); }} style={[styles.colorBox, { backgroundColor: 'silver' }]} />
        <TouchableOpacity onPress={() => { setSelectedColor('blue'); setScreen(3); }} style={[styles.colorBox, { backgroundColor: 'blue' }]} />
        <TouchableOpacity onPress={() => { setSelectedColor('gray'); setScreen(3); }} style={[styles.colorBox, { backgroundColor: 'gray' }]} />
      </View>
      <TouchableOpacity onPress={() => setScreen(1)} style={styles.doneButton}>
        <Text style={styles.doneButtonText}>XONG</Text>
      </TouchableOpacity>
    </View>
  );

  // Màn hình 3: Xác nhận màu đã chọn
  const Screen3 = () => (
    <View style={styles.container}>
      <Image source={{ uri: 'https://cdn2.cellphones.com.vn/x/media/catalog/product/i/p/iphone-15-pro-max_4__1.jpg' }} style={styles.image} />
      <Text style={styles.title}>iPhone 12 Pro Max 256GB</Text>
      <Text style={styles.subtitle}>Màu: {selectedColor}</Text>
      <TouchableOpacity onPress={() => setScreen(4)} style={styles.doneButton}>
        <Text style={styles.doneButtonText}>XONG</Text>
      </TouchableOpacity>
    </View>
  );

  // Màn hình 4: Hiển thị sản phẩm với màu đã chọn
  const Screen4 = () => (
    <View style={styles.container}>
      <Image source={{ uri: 'https://cdn2.cellphones.com.vn/x/media/catalog/product/i/p/iphone-15-pro-max_4__1.jpg' }} style={styles.image} />
      <Text style={styles.title}>iPhone 12 Pro Max 256GB</Text>
      <Text style={styles.rating}>★★★★☆ (Xem 828 đánh giá)</Text>
      <Text style={styles.subtitle}>Màu: {selectedColor}</Text>
      <Text style={styles.price}>27.590.000đ</Text>

      <TouchableOpacity onPress={() => setScreen(2)} style={styles.colorButton}>
        <Text style={styles.colorButtonText}>CHỌN MÀU</Text>
      </TouchableOpacity>
      
      <TouchableOpacity onPress={() => setScreen(1)} style={styles.buyButton}>
        <Text style={styles.buyButtonText}>CHỌN MUA</Text>
      </TouchableOpacity>
    </View>
  );

  return (
    <View style={styles.container}>
      {renderScreen()}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 16,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 20,
  },
  headerImage: {
    width: 100,
    height: 100,
    marginRight: 10,
  },
  headerText: {
    fontSize: 18,
    fontWeight: 'bold',
    color: 'gray',
  },
  image: {
    width: 150,
    height: 300,
    marginBottom: 20,
  },
  title: {
    fontSize: 18,
    fontWeight: 'bold',
    textAlign: 'center',
    marginBottom: 10,
  },
  subtitle: {
    fontSize: 16,
    color: 'gray',
    marginBottom: 20,
  },
  rating: {
    fontSize: 16,
    color: 'orange',
    marginBottom: 10,
  },
  price: {
    fontSize: 20,
    fontWeight: 'bold',
    color: 'red',
    marginBottom: 5,
  },
  oldPrice: {
    fontSize: 16,
    textDecorationLine: 'line-through',
    color: 'gray',
    marginBottom: 20,
  },
  colorButton: {
    backgroundColor: 'red',
    padding: 10,
    borderRadius: 5,
    marginTop: 10,
  },
  colorButtonText: {
    color: 'white',
    fontSize: 16,
    textAlign: 'center',
  },
  buyButton: {
    backgroundColor: 'green',
    padding: 10,
    borderRadius: 5,
    marginTop: 10,
  },
  buyButtonText: {
    color: 'white',
    fontSize: 16,
    textAlign: 'center',
  },
  colorOptionsVertical: {
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 20,
  },
  colorBox: {
    width: 50,
    height: 50,
    margin: 10,
    borderRadius: 5,
    borderWidth: 2,
    borderColor: 'gray',
  },
  doneButton: {
    backgroundColor: 'blue',
    padding: 10,
    borderRadius: 5,
    marginTop: 20,
  },
  doneButtonText: {
    color: 'white',
    fontSize: 16,
    textAlign: 'center',
  },
});