import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';
import { Provider } from 'react-redux';
import { store } from './redux/store'; // Import the store
import HomeScreen from './screens/HomeScreen';
import ProductListScreen from './screens/ProductListScreen';
import ProductDetailScreen from './screens/ProductDetailScreen';
import AdminScreen from './screens/AdminScreen';  // Import the Admin screen

const Stack = createStackNavigator();

export default function App() {
  return (
    <Provider store={store}>  {/* Wrap your app with Provider */}
      <NavigationContainer>
        <Stack.Navigator initialRouteName="Home" screenOptions={{ headerShown: false }}>
          <Stack.Screen name="Home" component={HomeScreen} />
          <Stack.Screen name="ProductList" component={ProductListScreen} />
          <Stack.Screen name="ProductDetail" component={ProductDetailScreen} />
          <Stack.Screen name="Admin" component={AdminScreen} />  {/* Add Admin screen */}
        </Stack.Navigator>
      </NavigationContainer>
    </Provider>
  );
}