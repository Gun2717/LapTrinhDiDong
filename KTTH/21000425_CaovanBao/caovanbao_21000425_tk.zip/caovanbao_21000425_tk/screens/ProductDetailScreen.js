import React from 'react';
import { View, Text, StyleSheet, Image, TouchableOpacity } from 'react-native';
import { useSelector, useDispatch } from 'react-redux';
import { addToCart } from '../redux/productSlice';

export default function ProductDetailScreen({ navigation }) {
  const product = useSelector((state) => state.products.selectedProduct);  // Get selected product from Redux
  const dispatch = useDispatch();

  const originalPrice = 499;  // Assume original price
  const discountPrice = (originalPrice - (originalPrice * 0.15)).toFixed(2);  // Calculate 15% OFF

  const handleAddToCart = () => {
    dispatch(addToCart(product));  // Add the selected product to the cart
    navigation.goBack();  // Navigate back to the ProductListScreen
  };

  return (
    <View style={styles.container}>
      <Image source={product.image} style={styles.productImage} />
      <Text style={styles.productName}>{product.name}</Text>

      <View style={styles.priceContainer}>
        <Text style={styles.productDiscount}>15% OFF | ${discountPrice}</Text>
        <Text style={styles.productOriginalPrice}>${originalPrice}</Text>
      </View>

      <TouchableOpacity onPress={handleAddToCart} style={styles.addButton}>
        <Text style={styles.addButtonText}>Add to Cart</Text>
      </TouchableOpacity>
    </View>
  );
}