import React, { useState } from 'react';
import { View, Text, StyleSheet, TextInput, Button, FlatList, TouchableOpacity, Alert } from 'react-native';
import { useSelector, useDispatch } from 'react-redux';
import { addToCart, removeFromCart, clearCart } from '../redux/productSlice'; // Import các hành động từ Redux

export default function AdminScreen() {
  const [newProductName, setNewProductName] = useState('');
  const [newProductPrice, setNewProductPrice] = useState('');
  const [newProductImage, setNewProductImage] = useState('');
  const products = useSelector((state) => state.products.products);  // Get products from Redux
  const dispatch = useDispatch();

  const handleAddProduct = () => {
    if (!newProductName || !newProductPrice || !newProductImage) {
      Alert.alert('Error', 'All fields are required!');
      return;
    }
    
    const newProduct = {
      id: (products.length + 1).toString(),  // Generate a new unique ID
      name: newProductName,
      price: newProductPrice,
      image: { uri: newProductImage },
    };

    // Dispatch action to add product
    dispatch({ type: 'products/addProduct', payload: newProduct });

    // Clear input fields
    setNewProductName('');
    setNewProductPrice('');
    setNewProductImage('');
  };

  const handleDeleteProduct = (id) => {
    Alert.alert(
      'Delete Product',
      'Are you sure you want to delete this product?',
      [
        { text: 'Cancel', style: 'cancel' },
        { text: 'Delete', onPress: () => dispatch({ type: 'products/deleteProduct', payload: id }) },
      ],
      { cancelable: true }
    );
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Admin Panel</Text>

      {/* Form to add new product */}
      <TextInput
        style={styles.input}
        placeholder="Product Name"
        value={newProductName}
        onChangeText={setNewProductName}
      />
      <TextInput
        style={styles.input}
        placeholder="Product Price"
        value={newProductPrice}
        onChangeText={setNewProductPrice}
        keyboardType="numeric"
      />
      <TextInput
        style={styles.input}
        placeholder="Product Image URL"
        value={newProductImage}
        onChangeText={setNewProductImage}
      />
      <Button title="Add Product" onPress={handleAddProduct} />

      {/* Product List */}
      <FlatList
        data={products}
        keyExtractor={(item) => item.id}
        renderItem={({ item }) => (
          <View style={styles.productItem}>
            <Text style={styles.productName}>{item.name}</Text>
            <Text style={styles.productPrice}>{item.price}</Text>
            <TouchableOpacity
              style={styles.deleteButton}
              onPress={() => handleDeleteProduct(item.id)}
            >
              <Text style={styles.deleteButtonText}>Delete</Text>
            </TouchableOpacity>
          </View>
        )}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
    backgroundColor: '#fff',
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    textAlign: 'center',
    marginBottom: 20,
  },
  input: {
    borderWidth: 1,
    borderColor: '#ccc',
    padding: 10,
    marginBottom: 10,
    borderRadius: 8,
  },
  productItem: {
    padding: 10,
    marginBottom: 10,
    borderBottomWidth: 1,
    borderBottomColor: '#ccc',
  },
  productName: {
    fontSize: 18,
    fontWeight: 'bold',
  },
  productPrice: {
    fontSize: 16,
    color: '#666',
  },
  deleteButton: {
    marginTop: 10,
    backgroundColor: '#ff6347',
    padding: 8,
    borderRadius: 8,
  },
  deleteButtonText: {
    color: '#fff',
    textAlign: 'center',
  },
});