import React from 'react';
import { View, Text, StyleSheet, FlatList, TouchableOpacity, Image } from 'react-native';
import { useSelector, useDispatch } from 'react-redux';
import { setSelectedProduct } from '../redux/productSlice';

export default function ProductListScreen({ navigation }) {
  const products = useSelector((state) => state.products.products);  // Get products from Redux
  const dispatch = useDispatch();

  const handleProductSelect = (product) => {
    dispatch(setSelectedProduct(product));  // Set selected product
    navigation.navigate('ProductDetail');  // Navigate to Product Detail screen
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>The world’s Best Bike</Text>

      <FlatList
        data={products}
        numColumns={2}
        keyExtractor={(item) => item.id}
        renderItem={({ item }) => (
          <View style={styles.productCard}>
            <TouchableOpacity onPress={() => handleProductSelect(item)}>
              <Image source={item.image} style={styles.productImage} />
            </TouchableOpacity>
            <Text style={styles.productName}>{item.name}</Text>
            <Text style={styles.productPrice}>{item.price}</Text>
          </View>
        )}
        contentContainerStyle={styles.productList}
      />
    </View>
  );
}