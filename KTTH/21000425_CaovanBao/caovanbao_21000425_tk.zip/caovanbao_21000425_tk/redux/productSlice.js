// redux/productSlice.js
import { createSlice } from '@reduxjs/toolkit';

const initialState = {
  products: [
    { id: '1', name: 'Pinarello', price: '$1700', image: require('../assets/s1.png') },
    { id: '2', name: 'Pina Mountain', price: '$1500', image: require('../assets/s21.png') },
    { id: '3', name: 'Pinarello', price: '$1900', image: require('../assets/s22.png') },
    { id: '4', name: 'Pina Bike', price: '$1500', image: require('../assets/s23.png') },
    { id: '5', name: 'Roadie', price: '$1800', image: require('../assets/s24.png') },
    { id: '6', name: 'Mountain Max', price: '$1600', image: require('../assets/s25.png') },
  ],
  selectedProduct: null,
  cart: [],
};

const productSlice = createSlice({
  name: 'products',
  initialState,
  reducers: {
    setSelectedProduct: (state, action) => {
      state.selectedProduct = action.payload;
    },
    addToCart: (state, action) => {
      state.cart.push(action.payload);
    },
    removeFromCart: (state, action) => {
      state.cart = state.cart.filter(product => product.id !== action.payload.id);
    },
    clearCart: (state) => {
      state.cart = [];
    },
    addProduct: (state, action) => {
      state.products.push(action.payload);  // Add a new product to the list
    },
    deleteProduct: (state, action) => {
      state.products = state.products.filter(product => product.id !== action.payload);  // Remove a product by ID
    },
  },
});

export const { setSelectedProduct, addToCart, removeFromCart, clearCart, addProduct, deleteProduct } = productSlice.actions;

export default productSlice.reducer;